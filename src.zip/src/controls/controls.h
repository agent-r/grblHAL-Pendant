#pragma once
#include <Arduino.h>
#include <TickTwo.h>

void controlsInit();

void handleEncoder(void *pvParameters);
void ESP_ISR callBack(NewEncoder*encPtr, const volatile NewEncoder::EncoderState *state, void *uPtr);
void checkEncoder();
bool EncoderChange();
int16_t readEncoder();
void resetEncoder();
void checkKeypad();
int readKeypad(bool buffered);
bool checkEnter();
bool checkEnterConfirm();
bool checkConfig();

// void checkBattery();

float readBattery();
int percentageBattery(const float Voltage);

extern TickTwo EncoderTicker;
extern TickTwo KeypadTicker;
