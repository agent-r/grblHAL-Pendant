#include <Arduino.h>
#include <ArduinoJson.h>

#include "controller/controller.h"
#include "debug/debug.h"
#include "controller/configmenu.h"
#include "display/display_functions.h"
#include "global/global.h"
#include "global/timer.h"

// -------------------------------------------------------------------
// ControlTask (das Gehirn)

// DisplayEvent dispEv;


void ControlTask(void *pv)
{

  InputEvent inEv;
  // DisplayEvent dispEv;

  systemState = STATE_RUN;

  JsonDocument bleRxDoc;

  char gCode[BLE_TX_MAX_LEN];
  char gCodeMessage[DISP_MAX_MENU_TEXT];

  volatile bool probing_completed_flag = false;
  volatile bool probing_triggered_flag = false;

  sleepReset(); // start sleep-timer

  for (;;)
  {

    // -------- Input Events --------
    if (xQueueReceive(inputQueue, &inEv, 0))
    {

      switch (systemState)
      {

      case STATE_RUN:

        if (inEv.type == ENC_MOVE)
        {
          float distance = cnc.factor * inEv.delta * cnc.axis[cnc.activeAxis].dir;
          snprintf(gCode, sizeof(gCode), "$J=G91%c%.3fF%d", cnc.axis[cnc.activeAxis].name, distance, cnc.axis[cnc.activeAxis].speed);
          snprintf(gCodeMessage, sizeof(gCodeMessage), "Jog %c%.3f", cnc.axis[cnc.activeAxis].name, distance);
          gCodeSend("gcode", gCode, gCodeMessage);
        }
        if (inEv.type == BTN_0)
        {
          if (cnc.activeAxis <= 0) { cnc.activeAxis = 3; }
          else { cnc.activeAxis--; }

          DisplayEvent dispEvAxisDecrease;
          dispEvAxisDecrease.state.activeAxis = cnc.activeAxis;

          char str[8]; 
          dtostrf(cnc.axis[0].pos,8,2,str); snprintf(dispEvAxisDecrease.state.x, DISP_MAX_TEXT, "%sX %s", (cnc.activeAxis == 0) ? ">" : " " , str);
          dtostrf(cnc.axis[1].pos,8,2,str); snprintf(dispEvAxisDecrease.state.y, DISP_MAX_TEXT, "%sY %s", (cnc.activeAxis == 1) ? ">" : " " , str);
          dtostrf(cnc.axis[2].pos,8,2,str); snprintf(dispEvAxisDecrease.state.z, DISP_MAX_TEXT, "%sZ %s", (cnc.activeAxis == 2) ? ">" : " " , str);
          dtostrf(cnc.axis[3].pos,8,2,str); snprintf(dispEvAxisDecrease.state.a, DISP_MAX_TEXT, "%sA %s", (cnc.activeAxis == 3) ? ">" : " " , str);
          dispEvAxisDecrease.state.axischange = true;
          dispEvAxisDecrease.type = DISP_UPDATE_POS;
          xQueueSend(displayQueue, &dispEvAxisDecrease, 0);
          // dispEvAxisDecrease.state.axischange = false;

        }
        if (inEv.type == BTN_1)
        {
          if (cnc.activeAxis >= 3) { cnc.activeAxis = 0; }
          else { cnc.activeAxis++; }

          DisplayEvent dispEvAxisIncrease;

          dispEvAxisIncrease.state.activeAxis = cnc.activeAxis;

          char str[8]; 
          dtostrf(cnc.axis[0].pos,8,2,str); snprintf(dispEvAxisIncrease.state.x, DISP_MAX_TEXT, "%sX %s", (cnc.activeAxis == 0) ? ">" : " " , str);
          dtostrf(cnc.axis[1].pos,8,2,str); snprintf(dispEvAxisIncrease.state.y, DISP_MAX_TEXT, "%sY %s", (cnc.activeAxis == 1) ? ">" : " " , str);
          dtostrf(cnc.axis[2].pos,8,2,str); snprintf(dispEvAxisIncrease.state.z, DISP_MAX_TEXT, "%sZ %s", (cnc.activeAxis == 2) ? ">" : " " , str);
          dtostrf(cnc.axis[3].pos,8,2,str); snprintf(dispEvAxisIncrease.state.a, DISP_MAX_TEXT, "%sA %s", (cnc.activeAxis == 3) ? ">" : " " , str);

          dispEvAxisIncrease.state.axischange = true;
          dispEvAxisIncrease.type = DISP_UPDATE_POS;

          xQueueSend(displayQueue, &dispEvAxisIncrease, 0);

        }
        if (inEv.type == BTN_2)
        {
          snprintf(gCode, sizeof(gCode), "G10L20P0%c0", cnc.axis[cnc.activeAxis].name);
          snprintf(gCodeMessage, sizeof(gCodeMessage), "Set %c 0", cnc.axis[cnc.activeAxis].name);
          gCodeSend("gcode", gCode, gCodeMessage);
        }

        if (inEv.type == BTN_3)
        {
          snprintf(gCode, sizeof(gCode), "$J=G90 %c0 F%d", cnc.axis[cnc.activeAxis].name, cnc.axis[cnc.activeAxis].speed);
          snprintf(gCodeMessage, sizeof(gCodeMessage), "GoTo %c 0",  cnc.axis[cnc.activeAxis].name);
          gCodeSend("gcode", gCode, gCodeMessage);
        }
        if (inEv.type == BTN_4)
        {
          systemState = STATE_PENDING_PROBING_CONFIRM;
          timerStart(TIMER_CONFIRM_PROBING, BUTTON_CONFIRM_ENTER_TIME, false);
          messageSend("Confirm: ENTER");
        }
        if (inEv.type == BTN_5)
        {
          systemState = STATE_CONFIGMENU;

          xQueueReset(bleRxQueue);    // reset queues
          xQueueReset(displayQueue);
          xQueueReset(inputQueue);

          initMenu();
        }
        if (inEv.type == BTN_6)
        {

          DisplayEvent dispEvFactorDecrease;

          if (cnc.factor <= 0.011) { cnc.factor = 100; }
          else { cnc.factor = cnc.factor / 10; }
          char strfactor[6]; dtostrf(cnc.factor,6,2,strfactor);
          snprintf(dispEvFactorDecrease.state.factor, sizeof(dispEvFactorDecrease.state.factor), " F   %s", strfactor);
          dispEvFactorDecrease.state.factorchange = true;
          dispEvFactorDecrease.type = DISP_UPDATE_POS;

          xQueueSend(displayQueue, &dispEvFactorDecrease, 0);

        }
        if (inEv.type == BTN_7)
        {

          DisplayEvent dispEvFactorIncrease;

          if (cnc.factor >= 99) { cnc.factor = 0.01; }
          else { cnc.factor = cnc.factor * 10; }
          char strfactor[6]; dtostrf(cnc.factor,6,2,strfactor);
          snprintf(dispEvFactorIncrease.state.factor, sizeof(dispEvFactorIncrease.state.factor), " F   %s", strfactor);
          dispEvFactorIncrease.state.factorchange = true;
          dispEvFactorIncrease.type = DISP_UPDATE_POS;

          xQueueSend(displayQueue, &dispEvFactorIncrease, 0);

        }
        if (inEv.type == BTN_8)
        {
            systemState = STATE_PENDING_HOMING_CONFIRM;
            timerStart(TIMER_CONFIRM_HOMING, BUTTON_CONFIRM_ENTER_TIME, false);
            messageSend("Confirm: ENTER");
        }
        if (inEv.type == BTN_9)
        {
          gCodeSend("cmd", "STOP", "Stop");
        }
        if (inEv.type == BTN_10)
        {
          gCodeSend("cmd", "UNLOCK", "Unlock");
       }
        if (inEv.type == BTN_11)
        {
          gCodeSend("cmd", "START", "Start");
        }
        break;

      case STATE_PENDING_HOMING_CONFIRM:

        if (inEv.type == BTN_11)
        {
          timerStop(TIMER_CONFIRM_HOMING);
          systemState = STATE_RUN;
          gCodeSend("cmd", "HOME", "Home All");
        }
      break;

      case STATE_PENDING_PROBING_CONFIRM:

        if (inEv.type == BTN_11)
        {
          timerStop(TIMER_CONFIRM_PROBING);
          gCodeSend("gcode", "G91", "Probing");
          snprintf(gCodeMessage, sizeof(gCodeMessage), "G38.2Z-%dF%d", config.ProbeDepth, config.ProbeSpeed);
          gCodeSend("gcode", gCodeMessage, "Probing");;
          timerStart(TIMER_PROBING, config.ProbeTime * 1000, false);
          systemState = STATE_PENDING_PROBING;
          probing_triggered_flag = false;
          probing_completed_flag = false;

        }
      break;

      case STATE_CONFIGMENU:

        if (inEv.type == ENC_MOVE)
        {
          updateMenu(inEv);
        }
        if (inEv.type == BTN_11)
        {
          updateMenu(inEv);
        }
        break;

        default:
        break;
      }

      sleepReset(); // reset Sleep-Timer if input recognised

    }

    // --------- BLE RX Event ------------
    BLERxEvent bleRxEv;
    if (xQueueReceive(bleRxQueue, &bleRxEv, 0))
    {
      if  (systemState == STATE_RUN || systemState == STATE_PENDING_HOMING_CONFIRM || systemState == STATE_PENDING_PROBING_CONFIRM || systemState == STATE_PENDING_PROBING)
      {
        char bleRxJson[BLE_RX_MAX_LEN + 1];
        size_t copyLen = bleRxEv.len;

        if (copyLen >= BLE_RX_MAX_LEN)
        {
          copyLen = BLE_RX_MAX_LEN - 1;
        }

        memcpy(bleRxJson, bleRxEv.json, copyLen);
        bleRxJson[copyLen] = '\0';

        debugLog(DBG_INFO, "CTRL", bleRxJson);

        DeserializationError error = deserializeJson(bleRxDoc, bleRxJson);

        if (error)
        {
          debugLog(DBG_ERROR, "CTRL", "JSON -> deserializeJson() failed");
        }

        DisplayEvent dispEvState;

        if (bleRxDoc["state"].is<const char*>())
        {

          const char* state = bleRxDoc["state"];
          snprintf(cnc.state, DISP_MAX_TEXT, "%s", state);

          if (strcmp(cnc.state, cnc.stateOld) != 0) {

            if (systemState == STATE_PENDING_PROBING && (strcmp(cnc.stateOld, "RUN") == 0) && (strcmp(cnc.state, "IDLE") == 0)) 
            {
                // if system state changes from RUN to IDLE -> Probing Suxxesfull !
                snprintf(gCodeMessage, sizeof(gCodeMessage), "G10L20P0Z%d", config.ProbeOffset);
                gCodeSend("gcode", gCodeMessage, "Probing OK");;
                snprintf(gCodeMessage, sizeof(gCodeMessage), "$J=G91Z%dF%d", config.ProbeReturn, cnc.axis[2].speed);
                gCodeSend("gcode", gCodeMessage, "Probing OK");;

                systemState == STATE_RUN;
            }

            snprintf(dispEvState.state.state, DISP_MAX_TEXT_MESSAGE_STATE, "%s", cnc.state);
            strncpy(cnc.stateOld, cnc.state, DISP_MAX_TEXT_MESSAGE_STATE - 1);
            dispEvState.state.statechange = true;
          }
        }

        if (bleRxDoc["wx"].is<float>())
        {
          cnc.axis[0].pos = bleRxDoc["wx"];
          char strwx[8]; dtostrf(cnc.axis[0].pos,8,2,strwx);
          if (cnc.axis[0].pos != cnc.axis[0].posOld) {
            snprintf(dispEvState.state.x, DISP_MAX_TEXT, "%sX %s", (cnc.activeAxis == 0) ? ">" : " " , strwx);
            cnc.axis[0].posOld = cnc.axis[0].pos;
            dispEvState.state.xchange = true;
          }
      }

        if (bleRxDoc["wy"].is<float>())
        {
          cnc.axis[1].pos = bleRxDoc["wy"];
          char strwy[8]; dtostrf(cnc.axis[1].pos,8,2,strwy);
          if (cnc.axis[1].pos != cnc.axis[1].posOld) {
            snprintf(dispEvState.state.y, DISP_MAX_TEXT, "%sY %s", (cnc.activeAxis == 1) ? ">" : " " , strwy);
            cnc.axis[1].posOld = cnc.axis[1].pos;
            dispEvState.state.ychange = true;
          }
        }

        if (bleRxDoc["wz"].is<float>())
        {
          cnc.axis[2].pos = bleRxDoc["wz"];
          char strwz[8]; dtostrf(cnc.axis[2].pos,8,2,strwz);
          if (cnc.axis[2].pos != cnc.axis[2].posOld) {
            snprintf(dispEvState.state.z, DISP_MAX_TEXT, "%sZ %s", (cnc.activeAxis == 2) ? ">" : " " , strwz);
            cnc.axis[2].posOld = cnc.axis[2].pos;
            dispEvState.state.zchange = true;
          }
        }

        if (bleRxDoc["wa"].is<float>())
        {
          cnc.axis[3].pos = bleRxDoc["wa"];
          char strwa[8]; dtostrf(cnc.axis[3].pos,8,2,strwa);
          if (cnc.axis[3].pos != cnc.axis[3].posOld) {
            snprintf(dispEvState.state.a, DISP_MAX_TEXT, "%sA %s", (cnc.activeAxis == 3) ? ">" : " " , strwa);
            cnc.axis[3].posOld = cnc.axis[3].pos;
            dispEvState.state.achange = true;
          }
        }

        if (bleRxDoc["probe"].is<const char*>())
        {
          const char* probe = bleRxDoc["probe"];

          if (strcmp(probe, "none") == 0) { }
          else if (strcmp(probe, "triggered") == 0)
          {
            probing_triggered_flag = true;
          }
          else if (strcmp(probe, "finished") == 0) 
          {
            probing_completed_flag = true;
          }
        }

        dispEvState.type = DISP_UPDATE_POS;
        xQueueSend(displayQueue, &dispEvState, 0);

      }

    }


    // --------- BLE Scan ------------
    BLEScanEvent bleScanEv;
    if (xQueueReceive(bleScanEventQueue, &bleScanEv, 0))
    {
      handleBLEScanEvent(bleScanEv);
    }

    // --------- Timer Events ------------

    TimerEvent timerEv;
    if (xQueueReceive(timerQueue, &timerEv, 0) )
    {

      if (systemState == STATE_PENDING_HOMING_CONFIRM)
      {
        if (timerEv.type == TIMER_EXPIRED && timerEv.id == TIMER_CONFIRM_HOMING)
        {
          systemState = STATE_RUN;
        }
      }

      if (systemState == STATE_PENDING_PROBING_CONFIRM)
      {
        if (timerEv.type == TIMER_EXPIRED && timerEv.id == TIMER_CONFIRM_PROBING)
        {
          systemState = STATE_RUN;
        }
      }

      if (timerEv.type == TIMER_EXPIRED && timerEv.id == TIMER_MESSAGE_SHOW) 
      {
        DisplayEvent dispEvMessageClear;

        dispEvMessageClear.type = DISP_UPDATE_POS;
        snprintf(dispEvMessageClear.state.message, DISP_MAX_TEXT, "%s", " ");
        dispEvMessageClear.state.messagechange = true;

        xQueueSend(displayQueue, &dispEvMessageClear, 0);

      }

      if (timerEv.type == TIMER_EXPIRED && timerEv.id == TIMER_SLEEP)
      {
            // BLE trennen
            BLECmd cmd = { BLE_DISCONNECT };
            xQueueSend(bleCmdQueue, &cmd, 0);

            // Display ausschalten
            DisplayEvent dispEvSleep;
            dispEvSleep.type = DISP_SLEEP;
            xQueueSend(displayQueue, &dispEvSleep, 0);

            // Zeit für Disconnect geben
            vTaskDelay(pdMS_TO_TICKS(200));

            // letzte Meldung
            debugLog(DBG_INFO, "CTRL", "Entering deep sleep");

            // GPIO Wakeup (z.B. Button) definieren
            esp_sleep_enable_ext0_wakeup( static_cast<gpio_num_t>(ENCODER_PIN_A), 1 ); // LOW = Wake
            
            // Optional: mehrere Pins
            // esp_sleep_enable_ext1_wakeup(mask, ESP_EXT1_WAKEUP_ANY_LOW);

            // ............... go to sleep ........................
            esp_deep_sleep_start();
      }


      if (timerEv.type == TIMER_EXPIRED && timerEv.id == TIMER_PROBING) 
      {
        
        DisplayEvent dispEvMessageClear;

        dispEvMessageClear.type = DISP_UPDATE_POS;
        snprintf(dispEvMessageClear.state.message, DISP_MAX_TEXT_MESSAGE_STATE, "Probing Aborted", " ");
        dispEvMessageClear.state.messagechange = true;

        xQueueSend(displayQueue, &dispEvMessageClear, 0);

        systemState = STATE_RUN;

      }


      


    }


    if (systemState == STATE_PENDING_PROBING) 
    {
      if (probing_triggered_flag) // success
      {
        timerStop(TIMER_PROBING);

        debugLog(DBG_INFO, "PROBE", "TRIGGER RECEIVED");

        gCodeSend("gcode", "G90", "Probing");
        snprintf(gCodeMessage, sizeof(gCodeMessage), "G10L20P0Z%d", config.ProbeOffset);
        gCodeSend("gcode", gCodeMessage, "Probing");;
        snprintf(gCodeMessage, sizeof(gCodeMessage), "$J=G91Z%dF%d", config.ProbeReturn, cnc.axis[2].speed);
        gCodeSend("gcode", gCodeMessage, "Probing");;

        systemState = STATE_RUN;

        probing_triggered_flag = false;
        probing_completed_flag = false;
      }
      else if (probing_completed_flag) // no success
      {
        timerStop(TIMER_PROBING);

        debugLog(DBG_INFO, "PROBE", "COMPLETED RECEIVED");

        gCodeSend("gcode", "G90", "Probing Error");
        snprintf(gCodeMessage, sizeof(gCodeMessage), "$J=G91Z%dF%d", config.ProbeReturn, cnc.axis[2].speed);
        gCodeSend("gcode", gCodeMessage, "Probing");;
        
        systemState = STATE_RUN;

        probing_triggered_flag = false;
        probing_completed_flag = false;
      }
    }

    vTaskDelay(1);

  }
}



////////////////////////////////////////////

void gCodeSend(const char* type, const char* gcode, const char* message) {

  BLETxEvent ev;

  JsonDocument bleTxDoc;
  bleTxDoc[type] = gcode;  // {"type":"gcode"}
  ev.len = serializeJson(bleTxDoc, ev.json, sizeof(ev.json));

  xQueueSend(bleTxQueue, &ev, 0);

  messageSend(message);

}


void messageSend(const char* message) {

  DisplayEvent dispEvMessage;

  dispEvMessage.type = DISP_UPDATE_POS;
  snprintf(dispEvMessage.state.message, DISP_MAX_TEXT_MESSAGE_STATE, "%s", message);
  dispEvMessage.state.messagechange = true;

  xQueueSend(displayQueue, &dispEvMessage, 0);

  timerStart(TIMER_MESSAGE_SHOW, TFT_MESSAGE_TIME_MS, false);
  
}


void sleepReset()
{

    if (config.SleepTime > 0) {
      timerStart(TIMER_SLEEP, config.SleepTime * 60000, false);
    }
    else {
      timerStop(TIMER_SLEEP);
    }

}