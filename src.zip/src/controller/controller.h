#pragma once
#include <Arduino.h>
#include "global/global.h"

void ControlTask(void *pv);
void gCodeSend(const char* type, const char* gcode, const char* message);
void messageSend(const char* message);
void sleepReset();