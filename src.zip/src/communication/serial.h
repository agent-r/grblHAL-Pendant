#pragma once
#include <Arduino.h>

void serialInit();