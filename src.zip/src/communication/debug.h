#pragma once
#include <Arduino.h>

void debug(const String& msg);