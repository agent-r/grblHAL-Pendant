#pragma once
#include <Arduino.h>

void debug(String msg);
