
#pragma once
#include <Arduino.h>

// ROTARY ENCODER
void InputTask(void* pv);