#pragma once
#include <Arduino.h>

extern const uint8_t TFT_FONT_19[] PROGMEM;
extern const uint8_t TFT_FONT_28[] PROGMEM;