///////////////////////////////////////////////////////////////////////////
///////////////////////       DISPLAY       ///////////////////////////////
///////////////////////////////////////////////////////////////////////////

#include <Arduino.h>
#include <TFT_eSPI.h> // TFT
// #include "driver/adc.h"             // FOR SLEEP !
#include "display/display_functions.h"
#include "display/display.h"
#include "global/global.h"
#include "display/fonts.h"


const int Fields[7][6] = {
    {10, 20, 220, 35, 3, 30},  // Field X  { X, Y, X-Width, Y-Widht, FontSize, Text-Y-Versatz }
    {10, 60, 220, 35, 3, 30},  // Field Y
    {10, 100, 220, 35, 3, 30}, // Field Z
    {10, 140, 220, 35, 3, 30}, // Field A
    {10, 190, 220, 35, 3, 30}, // Field F
    {10, 245, 220, 28, 2, 22}, // Field Status
    {10, 278, 220, 28, 2, 22}  // Field Message
};
const int Line[3] = {0, 234, 240};

// --------------------------------------
bool blinker = true;
bool blinker_change = true;

void TFTPrint(const byte Aim, String Content, const int Color)
{
        Content = Content.substring(0, 20);
        tft.fillRect(Fields[Aim][0], Fields[Aim][1], Fields[Aim][2], Fields[Aim][3], TFT_COLOR_FRM_BGR);
        TFTSetFontSize(Fields[Aim][4]);
        tft.setTextColor(Color, TFT_COLOR_FRM_BGR);
        tft.setCursor(Fields[Aim][0] + 7, Fields[Aim][1] + Fields[Aim][5]);
        tft.print(Content);
}

void TFTSetFontSize(const int size)
{
        if (size == 2)
        {
                tft.setFreeFont(&TFT_FONT_SMALL);
        }
        else if (size == 3)
        {
                tft.setFreeFont(&TFT_FONT_LARGE);

        }
}

void TFTPrepare()
{

        tft.fillRect(0, 0, 240, 320, TFT_COLOR_BGR);
        for (int i = 0; i <= 6; i++)
        {
                tft.drawRect(Fields[i][0] - 1, Fields[i][1] - 1, Fields[i][2] + 2, Fields[i][3] + 2, TFT_COLOR_FRM_LIN);
        }
        tft.drawFastHLine(Line[0], Line[1], Line[2], TFT_COLOR_FRM_LIN);
        TFTClear();
}

void TFTClear()
{
        for (int i = 0; i <= 6; i++)
        {
                tft.fillRect(Fields[i][0], Fields[i][1], Fields[i][2], Fields[i][3], TFT_COLOR_FRM_BGR);
        }
}

void TFTMessage()
{
        tft.fillRect(Fields[6][0], Fields[6][1], Fields[6][2], Fields[6][3], TFT_COLOR_FRM_BGR);
}

void TFTBlink()
{
        blinker = !blinker;
        blinker_change = true;
}

void TFTSleep() 
{
        analogWrite(TFT_LED_PIN, 0);    // turn off TFT Backlight
        tft.writecommand(TFT_DISPOFF);  // ??
        tft.writecommand(ILI9341_SLPIN);
}

//////////////////////////////////////////// CONFIG MENU /////////////////////////////////////////

const int ConfigForms[2][5] = {
    {10, 15, 220, 35, 3}, // Field Heading
    {10, 60, 220, 250, 2} // Field Content
};

const int ConfigFields[12][6] = {
    {10, 17, 220, 33, 3, 28}, // HEADING { X, Y, X-Width, Y-Widht, FontSize, Text-Y-Versatz }
    {10, 62, 220, 22, 2, 20}, // CONTENT
    {10, 84, 220, 22, 2, 20},
    {10, 106, 220, 22, 2, 20},
    {10, 128, 220, 22, 2, 20},
    {10, 150, 220, 22, 2, 20},
    {10, 172, 220, 22, 2, 20},
    {10, 194, 220, 22, 2, 20},
    {10, 216, 220, 22, 2, 20},
    {10, 238, 220, 22, 2, 20},
    {10, 260, 220, 22, 2, 20},
    {10, 282, 220, 22, 2, 20},
};

void TFTMenuPrepare()
{
        tft.fillRect(0, 0, 240, 320, TFT_COLOR_BGR);
        tft.drawRect(ConfigForms[0][0] - 1, ConfigForms[0][1] - 1, ConfigForms[0][2] + 2, ConfigForms[0][3] + 2, TFT_COLOR_FRM_LIN);
        tft.fillRect(ConfigForms[0][0], ConfigForms[0][1], ConfigForms[0][2], ConfigForms[0][3], TFT_COLOR_FRM_BGR);
        tft.drawRect(ConfigForms[1][0] - 1, ConfigForms[1][1] - 1, ConfigForms[1][2] + 2, ConfigForms[1][3] + 2, TFT_COLOR_FRM_LIN);
        tft.fillRect(ConfigForms[1][0], ConfigForms[1][1], ConfigForms[1][2], ConfigForms[1][3], TFT_COLOR_FRM_BGR);
}

void TFTMenuPrint(const byte Aim, String Content, const int Color)
{
        Content = Content.substring(0, 20);
        tft.fillRect(ConfigFields[Aim][0], ConfigFields[Aim][1], ConfigFields[Aim][2], ConfigFields[Aim][3], TFT_COLOR_FRM_BGR);
        TFTSetFontSize(ConfigFields[Aim][4]);
        tft.setTextColor(Color, TFT_COLOR_FRM_BGR);
        tft.setCursor(ConfigFields[Aim][0] + 7, ConfigFields[Aim][1] + ConfigFields[Aim][5]);
        tft.print(Content);
}

void TFTMenuPrintAddress(const byte Aim, String Content1, String Content2, String Content3, const int ColorNormal, const int ColorHighlight)
{
        TFTSetFontSize(ConfigFields[Aim][4]);
        tft.setCursor(ConfigFields[Aim][0] + 7, ConfigFields[Aim][1] + ConfigFields[Aim][5]);
        tft.setTextColor(ColorNormal, TFT_COLOR_FRM_BGR);
        tft.print(Content1);
        tft.setTextColor(ColorHighlight, TFT_COLOR_FRM_BGR);
        tft.print(Content2);
        tft.setTextColor(ColorNormal, TFT_COLOR_FRM_BGR);
        tft.print(Content3);
}