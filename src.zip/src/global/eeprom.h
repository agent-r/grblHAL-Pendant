
#pragma once
#include <Arduino.h>

// ROTARY ENCODER
void eepromLoad();
void eepromSave();