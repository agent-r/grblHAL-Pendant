#include <Arduino.h>
#include "global.h"

// hier alle globalen zustände einmal definieren!

CONFIG config;
CNC cnc;

volatile SystemState systemState = STATE_STARTUP;

void defaultsLoad() {
// pos, posOld, speed, dir, name
cnc.axis[0] = { 0, 0, 0, 1, 'X'};
cnc.axis[1] = { 0, 0, 0, 1, 'Y'};
cnc.axis[2] = { 0, 0, 0, -1, 'Z'};
cnc.axis[3] = { 0, 0, 0, 1, 'A'};
}

