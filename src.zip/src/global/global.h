#pragma once
#include <Arduino.h>


//////////////////////////////////////////// LOAD DEFAULTS //////////////////////////////

void defaultsLoad();

//////////////////////////////////////////// STATES /////////////////////////////////////////

// =======================
// System State
// =======================
enum SystemState
{
    STATE_STARTUP,
    STATE_RUN,
    STATE_PENDING_HOMING_CONFIRM,
    STATE_PENDING_PROBING_CONFIRM,
    STATE_PENDING_PROBING,
    STATE_CONFIGMENU,
    STATE_SLEEP,
    STATE_ERROR
};

extern volatile SystemState systemState;

// =======================
// Input Events (Buttons & Encoder)
// =======================
enum InputEventType
{
    BTN_0,
    BTN_1,
    BTN_2,
    BTN_3,
    BTN_4,
    BTN_5,
    BTN_6,
    BTN_7,
    BTN_8,
    BTN_9,
    BTN_10,
    BTN_11,
    ENC_MOVE
};

struct InputEvent
{
    InputEventType type;
    int32_t delta; // optional für Encoder, default 0
};


// =======================
// Display Events
// =======================

enum DisplayEventType
{
    // DISP_REDRAW,
    DISP_PREPARE,
    DISP_UPDATE_POS,
    DISP_MENU_PREPARE,
    DISP_MENU_NAV_UPDATE,
    DISP_MENU_LINE_UPDATE,
    DISP_MENU_ADDRESS_UPDATE,
    DISP_MENU_EXIT,
    DISP_SLEEP
    // DISP_SHOW_ERROR
};

#define DISP_MAX_MENU_ITEMS 11
#define DISP_MAX_MENU_TITLE_TEXT 12
#define DISP_MAX_MENU_TEXT 19
#define DISP_MAX_TEXT 12
#define DISP_MAX_TEXT_MESSAGE_STATE 19

struct DisplayStateData
{
    char x[DISP_MAX_TEXT] = {">X     0.00"};
    char y[DISP_MAX_TEXT] = {" Y     0.00"};
    char z[DISP_MAX_TEXT] = {" Z     0.00"};
    char a[DISP_MAX_TEXT] = {" A     0.00"};
    char factor[DISP_MAX_TEXT] = {" F     1.00"};
    char state[DISP_MAX_TEXT_MESSAGE_STATE] = {""};
    char message[DISP_MAX_TEXT_MESSAGE_STATE] = {""};
    bool xchange = false;
    bool ychange = false;
    bool zchange = false;
    bool achange = false;
    bool axischange = false;
    bool factorchange = false;
    bool statechange = false;
    bool messagechange = false;
    uint8_t activeAxis = 0;
};

struct DisplayNavMenuData
{
    char title[DISP_MAX_MENU_TITLE_TEXT];
    uint8_t itemCount;
    uint8_t activeIndex;
    char items[DISP_MAX_MENU_ITEMS][DISP_MAX_MENU_TEXT];
};

struct DisplayLineMenuData
{
    char title[DISP_MAX_MENU_TITLE_TEXT];
    uint8_t line;                  // "x speed: "
    char printLine[DISP_MAX_MENU_TEXT]; // "%d"
};

struct DisplayAddressMenuData
{
    char left[DISP_MAX_MENU_TEXT];
    char mid[DISP_MAX_MENU_TEXT];
    char right[DISP_MAX_MENU_TEXT];
    char title[DISP_MAX_MENU_TITLE_TEXT];
};

struct DisplayEvent
{
    DisplayEventType type;
    DisplayStateData state;
    DisplayNavMenuData nav;
    DisplayLineMenuData line;
    DisplayAddressMenuData bleaddress;
};

// =======================
// BLE Status Events
// =======================
enum BLEStatusType
{
    BLE_CONNECTED,
    BLE_DISCONNECTED,
    BLE_SCANNING,
    BLE_ERROR
};

// BLE RX
#define BLE_RX_MAX_LEN 128

struct BLERxEvent
{
    char json[BLE_RX_MAX_LEN + 1]; // +1 für '\0'
    uint8_t len;
};

// BLE TX
#define BLE_TX_MAX_LEN 128

struct BLETxEvent
{
    char json[BLE_TX_MAX_LEN + 1]; // +1 für '\0'
    uint8_t len;
};

// BLE SCAN FOR DEVICES
#define MAX_BLE_DEVICES 60
#define BLE_SCAN_DURATION 10000
#define BLE_SCAN_DURATION_SEC 10

struct BLEScanResult
{
    char name[DISP_MAX_MENU_TEXT];
    uint8_t address[6];
};

enum BLEScanEventType
{
    BLE_SCAN_STARTED,
    BLE_SCAN_RESULT,
    BLE_SCAN_FINISHED
};

struct BLEScanEvent
{
    BLEScanEventType type;
    BLEScanResult result; // nur gültig bei BLE_SCAN_RESULT
};

enum BLECmdType
{
    BLE_SCAN_START,
    BLE_SCAN_STOP,
    BLE_DISCONNECT
};

struct BLECmd
{
    BLECmdType type;
};

// =======================
// Debug Events
// =======================
enum DebugLevel
{
    DBG_ERROR,
    DBG_WARN,
    DBG_INFO,
    DBG_VERBOSE
};

#define DEBUG_MSG_LEN 512

struct DebugEvent
{
    DebugLevel level;
    const char *source;
    char msg[DEBUG_MSG_LEN];
};


// =======================
// TIMER
// =======================

enum TimerID
{
    TIMER_CONFIRM_HOMING,
    TIMER_CONFIRM_PROBING,
    TIMER_PROBING,
    TIMER_MESSAGE_SHOW,
    TIMER_MESSAGE_BLINK,
    TIMER_SLEEP
};


// =======================
// Queues & Handles
// =======================
extern QueueHandle_t inputQueue;
extern QueueHandle_t timerQueue;
extern QueueHandle_t bleRxQueue;
extern QueueHandle_t bleTxQueue;
extern QueueHandle_t bleScanEventQueue;
extern QueueHandle_t bleCmdQueue;
extern QueueHandle_t displayQueue;
extern QueueHandle_t debugQueue;

// extern TaskHandle_t timerTaskHandle;

//////////////////////////////////////////// DEFINITIONS /////////////////////////////////////////

// =======================
// Bluetooth Config
// =======================

#define BLE_SERVICE_UUID "825aeb6e-7e1d-4973-9c75-30c042c4770c"
#define BLE_TX_UUID "24259347-9d86-4c67-a9ae-84f6a7f0c90d" // PENDANT → TEENSY
#define BLE_RX_UUID "b52e05ac-8a8a-4880-85c7-bd3e6a32dc0e" // TEENSY → PENDANT

#define BLE_MTU 247

// =======================
// Encoder Config
// =======================

#define ENCODER_PIN_A 36
#define ENCODER_PIN_B 39

// =======================
// Button Config
// =======================
#define BUTTON_PIN_0 32    // AX-
#define BUTTON_PIN_1 33    // AX+
#define BUTTON_PIN_2 5     // SET0
#define BUTTON_PIN_3 25    // GOTO0
#define BUTTON_PIN_4 26    // PROBE
#define BUTTON_PIN_5 27    // CONFIG
#define BUTTON_PIN_6 14    // FEED-
#define BUTTON_PIN_7 13    // FEED+
#define BUTTON_PIN_8 16    // HOME
#define BUTTON_PIN_9 4     // STOP
#define BUTTON_PIN_10 2    // RESET
#define BUTTON_PIN_11 15   // ENTER

#define BUTTON_DEBOUNCE 30 // Debounce for Buttons
#define BUTTON_CONFIRM_ENTER_TIME 3000

#define INPUT_POLL_INTERVAL_MS 10 // Abfrage alle 10ms
#define INPUT_POLL_MULTIPLIER_ENCODER 10

// =======================
// Task Priorities & STACK SIZES
// =======================
#define DEBUG_TASK_PRIO 4
#define TIMER_TASK_PRIO 3
#define INPUT_TASK_PRIO 3
#define CONTROL_TASK_PRIO 2
#define DISPLAY_TASK_PRIO 2
#define BLE_TASK_PRIO 1

#define TASK_STACK_SIZE 4096
#define TASK_STACK_SIZE_TIMER 2048

// =======================
// TFT DISPLAY
// =======================

// TFT
/*
TFT PINS ARE DEFINED IN TFT_ESPI -> USER_SETUP.h
#define TFT_SCK    18
#define TFT_MOSI   23
#define TFT_DC     21       //
#define TFT_CS     22       //
#define TFT_RST     4       // TO VCC !!!
*/

#define TFT_LED_PIN 17
#define TFT_ROTATION 2

#define TFT_FONT_SMALL TFT_FONT_11
#define TFT_FONT_LARGE TFT_FONT_18
#define TFT_COLOR_BGR 0xDEFB
#define TFT_COLOR_FRM_BGR 0xFFFF
#define TFT_COLOR_FRM_LIN 0x7BEF
#define TFT_COLOR_XYZ 0x0000
#define TFT_COLOR_XYZ_INACTIVE 0x94B2
#define TFT_COLOR_STA_NRM 0x6680
#define TFT_COLOR_STA_ERR 0xF80A
#define TFT_COLOR_MSG_NRM 0x8430
#define TFT_COLOR_MSG_ERR 0xF80A
#define TFT_COLOR_CNF_STD 0x0000
#define TFT_COLOR_CNF_HIL 0xF80A

#define TFT_MESSAGE_TIME_MS 2500

// SLEEP
// #define bitSet64(value, bit) ((value) |= (1ULL << (bit)))

// =======================
// EEPROM
// =======================
#define EEPROM_LENGTH 512
#define EEBluetoothHost "BTH"
#define EEBluetoothPin "BTP"
#define EEJogSpeed "JSP"
#define EEProbeOffset "POF"
#define EEProbeDepth "PDE"
#define EEProbeSpeed "PSP"
#define EEProbeBackHeight "PBH"
#define EEProbeTime "PTI"
#define EESleepTime "STI"
#define EEBrightness "BRI"


//////////////////////////////////////////// VARIABLES /////////////////////////////////////////

// ---------- CONFIG Objekt ----------
struct CONFIG
{

    // Workspace
    uint8_t workspace = 54;

    // Probe
    float ProbeOffset = 10.0;
    uint16_t ProbeSpeed = 100;
    uint16_t ProbeDepth = 10;
    uint8_t ProbeReturn = 10;
    uint8_t ProbeTime = 10;
    bool ProbeAlarm = false;

    // Display
    uint8_t SleepTime = 1;
    uint8_t TFTBrightness = 127;

    // Bluetooth
    uint8_t BluetoothHost[6] = { 0 };
    uint16_t BluetoothPin = 0;

};

// Globale CONFIG Instanz
extern CONFIG config;


// ---------- CNC Objekt ----------

struct Axes
{
    float pos;
    float posOld;
    uint16_t speed;   // JogSpeed
    int8_t dir; // Richtung
    char name;
};

struct CNC
{

    // Achsen
    Axes axis[4];
    uint8_t activeAxis = 0; // Index oder Mapping

    // Factor
    float factor = 1.00;

    // State
    char state[DISP_MAX_TEXT_MESSAGE_STATE] = {""};
    char stateOld[DISP_MAX_TEXT_MESSAGE_STATE] = {""};

};

extern CNC cnc;


///////////////////////////////////////////// MAKROS ////////////////////////////////////////////////////

#define DEBUGF(lvl, src, fmt, ...)                        \
    do                                                    \
    {                                                     \
        char __buf[DEBUG_MSG_LEN];                        \
        snprintf(__buf, sizeof(__buf), fmt, __VA_ARGS__); \
        debugLog(lvl, src, __buf);                        \
    } while (0)